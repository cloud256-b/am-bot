#!/bin/bash
python flask_bot_app.py
